(function(){
'use strict';
var D=window.TBFX||{bots:[],config:{}};
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var store={get:function(k){try{return localStorage.getItem(k)}catch(e){return null}},set:function(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
function toast(msg){var t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(function(){t.classList.remove('show')},3800)}
function money(n){return '$'+n.toLocaleString(undefined,{maximumFractionDigits:2,minimumFractionDigits:2})}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}

/* ---------- nav ---------- */
var mb=$('.menu-btn'),nl=$('.navlinks');
if(mb){mb.addEventListener('click',function(){var o=nl.classList.toggle('open');mb.setAttribute('aria-expanded',o)})}

/* ---------- hero candles (simulation, not real data) ---------- */
var cv=$('#candles');
if(cv){
  var ctx=cv.getContext('2d'),W,H,dpr=Math.min(window.devicePixelRatio||1,2),cw=22,candles=[],markers=[],price=0,off=0,frame=0;
  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function size(){var r=cv.getBoundingClientRect();W=r.width;H=r.height;cv.width=W*dpr;cv.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
  function next(){var o=price,drift=(Math.random()-.47)*14,c=o+drift,hi=Math.max(o,c)+Math.random()*9,lo=Math.min(o,c)-Math.random()*9;price=c;return {o:o,c:c,h:hi,l:lo}}
  function seed(){candles=[];price=0;var n=Math.ceil(W/cw)+4;for(var i=0;i<n;i++)candles.push(next())}
  function draw(){
    ctx.clearRect(0,0,W,H);
    var min=1e9,max=-1e9;candles.forEach(function(k){min=Math.min(min,k.l);max=Math.max(max,k.h)});
    var pad=H*.18,sc=(H-pad*2)/(max-min||1);
    function y(v){return H-pad-(v-min)*sc}
    ctx.lineWidth=1;
    candles.forEach(function(k,i){
      var x=i*cw-off+cw/2,up=k.c>=k.o;
      ctx.strokeStyle=up?'rgba(184,242,75,.9)':'rgba(255,107,94,.85)';
      ctx.fillStyle=up?'rgba(184,242,75,.5)':'rgba(255,107,94,.45)';
      ctx.beginPath();ctx.moveTo(x,y(k.h));ctx.lineTo(x,y(k.l));ctx.stroke();
      var top=y(Math.max(k.o,k.c)),hh=Math.max(2,Math.abs(y(k.o)-y(k.c)));
      ctx.fillRect(x-6,top,12,hh);ctx.strokeRect(x-6,top,12,hh);
    });
    markers.forEach(function(m){
      var k=candles[m.i];if(!k)return;var x=m.i*cw-off+cw/2,yy=m.buy?y(k.l)+26:y(k.h)-26;
      ctx.fillStyle='#f2b632';ctx.beginPath();
      if(m.buy){ctx.moveTo(x,yy-14);ctx.lineTo(x-6,yy-4);ctx.lineTo(x+6,yy-4)}else{ctx.moveTo(x,yy+14);ctx.lineTo(x-6,yy+4);ctx.lineTo(x+6,yy+4)}
      ctx.fill();ctx.font='600 11px DM Sans,sans-serif';ctx.textAlign='center';ctx.fillText(m.buy?'BOT BUY':'BOT SELL',x,m.buy?yy+8:yy-2);
    });
  }
  function tick(){
    off+=.6;
    if(off>=cw){off-=cw;candles.shift();candles.push(next());markers.forEach(function(m){m.i--});markers=markers.filter(function(m){return m.i>1});
      if(++frame%11===0){var i=candles.length-3;markers.push({i:i,buy:candles[i].c>=candles[i].o})}}
    draw();requestAnimationFrame(tick);
  }
  size();seed();
  if(reduce){markers.push({i:Math.floor(candles.length*.6),buy:true});draw()}else{requestAnimationFrame(tick)}
  window.addEventListener('resize',function(){size();seed();draw()});
}

/* ---------- enquiry modal ---------- */
var modal=$('#enquiry');
function openModal(subject,msg){
  if(!modal)return;
  $('#eq-subject').value=subject||'General enquiry';
  $('#eq-title').textContent=subject||'Send an enquiry';
  $('#eq-msg').value=msg||'';
  modal.classList.add('open');setTimeout(function(){$('#eq-name').focus()},30);
}
function closeModal(){if(modal)modal.classList.remove('open')}
$$('[data-enquire]').forEach(function(b){b.addEventListener('click',function(){openModal(b.getAttribute('data-enquire'),b.getAttribute('data-msg')||'')})});
$$('.modal [data-close]').forEach(function(b){b.addEventListener('click',function(){var m=b.closest('.modal');m.classList.remove('open')})});
$$('.modal').forEach(function(m){m.addEventListener('click',function(e){if(e.target===m)m.classList.remove('open')})});
document.addEventListener('keydown',function(e){if(e.key==='Escape')$$('.modal.open').forEach(function(m){m.classList.remove('open')})});
var eqf=$('#eq-form');
if(eqf){eqf.addEventListener('submit',function(e){
  e.preventDefault();
  var f=new FormData(eqf),c=D.config||{};
  var text='New enquiry from the TechBroFX website\nTopic: '+f.get('subject')+'\nName: '+f.get('name')+'\nContact: '+f.get('contact')+'\nPlatform: '+f.get('platform')+'\n\n'+f.get('msg');
  if(c.telegram){window.open('https://t.me/'+c.telegram.replace('@','')+'?text='+encodeURIComponent(text),'_blank','noopener');toast('Opening Telegram with your message ready to send.')}
  else if(c.whatsapp){window.open('https://wa.me/'+c.whatsapp.replace(/\D/g,'')+'?text='+encodeURIComponent(text),'_blank','noopener');toast('Opening WhatsApp with your message ready to send.')}
  else if(c.email){window.location.href='mailto:'+c.email+'?subject='+encodeURIComponent('TechBroFX: '+f.get('subject'))+'&body='+encodeURIComponent(text)}
  else{(navigator.clipboard?navigator.clipboard.writeText(text):Promise.reject()).then(function(){toast('Message copied. Contact channels are not set up yet, so paste it to us directly.')},function(){toast('Contact channels are not set up yet. Add them in data.json.')})}
  closeModal();
})}

/* ---------- catalog filters + compare ---------- */
var cat=$('#catalog');
if(cat){
  var cards=$$('.bot',cat),fp=$('#f-platform'),fr=$('#f-risk'),fl=$('#f-level'),fq=$('#f-q'),cnt=$('#f-count'),emp=$('#f-empty');
  function applyF(){
    var n=0,q=fq.value.trim().toLowerCase();
    cards.forEach(function(c){
      var ok=(!fp.value||c.dataset.platforms.indexOf(fp.value)>-1)&&(!fr.value||c.dataset.risk===fr.value)&&(!fl.value||c.dataset.level===fl.value)&&(!q||c.dataset.search.indexOf(q)>-1);
      c.hidden=!ok;if(ok)n++;
    });
    cnt.textContent=n+(n===1?' bot':' bots');emp.hidden=n>0;
  }
  [fp,fr,fl].forEach(function(el){el.addEventListener('change',applyF)});fq.addEventListener('input',applyF);applyF();
  var dr=$('#drawer'),picked=[];
  function bot(id){return D.bots.filter(function(b){return b.id===id})[0]}
  function upd(){
    dr.classList.toggle('open',picked.length>0);
    $('#cmp-n').textContent=picked.length+' selected (pick 2 or 3)';
    $('#cmp-go').disabled=picked.length<2;
  }
  $$('.cmp input',cat).forEach(function(cb){cb.addEventListener('change',function(){
    if(cb.checked){if(picked.length>=3){cb.checked=false;toast('You can compare up to 3 bots.');return}picked.push(cb.value)}
    else picked=picked.filter(function(x){return x!==cb.value});
    upd();
  })});
  $('#cmp-clear').addEventListener('click',function(){picked=[];$$('.cmp input',cat).forEach(function(c){c.checked=false});upd()});
  $('#cmp-go').addEventListener('click',function(){
    var bs=picked.map(bot),rk=['','Lower','Medium','Higher'];
    var rows=[['Platform',function(b){return b.platforms.join(', ')}],['Style',function(b){return b.style}],['Style risk',function(b){return rk[b.risk]}],['Experience',function(b){return b.level}],['Uses a grid',function(b){return b.grid?'Yes':'No'}],['News filter',function(b){return b.news?'Yes':'No'}],['Best for',function(b){return b.best_for}],['Watch out for',function(b){return b.caution}]];
    var h='<table class="cmp-table"><thead><tr><th></th>'+bs.map(function(b){return '<th><a class="gold" href="bots/'+b.id+'.html">'+esc(b.name)+'</a></th>'}).join('')+'</tr></thead><tbody>';
    rows.forEach(function(r){h+='<tr><th>'+r[0]+'</th>'+bs.map(function(b){return '<td>'+esc(r[1](b))+'</td>'}).join('')+'</tr>'});
    $('#cmp-body').innerHTML=h+'</tbody></table>';$('#cmp-modal').classList.add('open');
  });
}

/* ---------- matchmaker quiz ---------- */
var qz=$('#quiz');
if(qz){
  var Q=[
   {k:'exp',t:'How would you describe your trading experience?',o:[['new','Brand new','I have never traded, or only a few times'],['some','Some experience','I understand charts, lots and stop losses'],['pro','Experienced','I have run EAs before and read backtests']]},
   {k:'goal',t:'What are you here to do?',o:[['learn','Learn safely','Watch a bot trade while I pick up the basics'],['grow','Grow my own account','Run a bot on my personal live account'],['prop','Pass a prop firm challenge','Use a bot within a firm\'s rules']]},
   {k:'plat',t:'Which platform will you use?',o:[['MetaTrader 5','MetaTrader 5','Most brokers and prop firms offer it'],['TradeLocker','TradeLocker','Modern platform used by many prop firms'],['any','Not sure yet','Show me everything']]},
   {k:'dd',t:'How would you feel if your account dropped 20% before recovering?',o:[['1','I would panic','Keep the risk low for me'],['2','I could handle it','Medium risk is fine'],['3','It is part of the game','I accept higher risk for faster activity']]}
  ],ans={},step=0;
  function renderQ(){
    var q=Q[step];
    $('#q-bar').style.width=(step/Q.length*100)+'%';
    $('#q-body').innerHTML='<div class="q-title" id="q-t" tabindex="-1">'+q.t+'</div><div class="opts">'+q.o.map(function(o){return '<button class="opt" data-v="'+o[0]+'">'+o[1]+'<span>'+o[2]+'</span></button>'}).join('')+'</div>'+(step?'<p style="margin-top:18px"><button class="btn sm" id="q-back">Back</button></p>':'');
    $$('.opt',qz).forEach(function(b){b.addEventListener('click',function(){ans[q.k]=b.dataset.v;step++;step<Q.length?renderQ():result()})});
    var bk=$('#q-back');if(bk)bk.addEventListener('click',function(){step--;renderQ()});
    if(step)$('#q-t').focus();
  }
  function result(){
    $('#q-bar').style.width='100%';
    var maxr=+ans.dd,scored=D.bots.map(function(b){
      var s=0,why=[];
      if(ans.plat!=='any'){if(b.platforms.indexOf(ans.plat)<0)return null;why.push('Runs on '+ans.plat)}
      if(b.risk<=maxr){s+=2;why.push('Style risk fits your comfort level')}else{s-=3*(b.risk-maxr)}
      if(ans.exp==='new'){if(b.level==='beginner'){s+=3;why.push('Beginner-friendly setup')}if(b.level==='advanced')s-=4}
      if(ans.exp==='some'&&b.level==='intermediate'){s+=1}
      if(ans.exp==='pro'&&b.level!=='beginner'){s+=1}
      if(ans.goal==='prop'){if(!b.grid){s+=3;why.push('No grid or recovery, which many prop firms restrict')}else s-=5;if(b.news){s+=1;why.push('Has a news filter')}}
      if(ans.goal==='learn'){if(b.level==='beginner')s+=1;if(b.news){s+=1;why.push('Steps aside around big news')}}
      return {b:b,s:s,why:why};
    }).filter(Boolean).sort(function(a,b){return b.s-a.s}).slice(0,3);
    var h='<div class="q-title">Your top matches</div><div class="result">';
    if(!scored.length)h+='<p class="empty">No bots match all of that yet. Try changing the platform.</p>';
    scored.forEach(function(r,i){h+='<div class="rec"><div class="rank">'+(i+1)+'</div><div><h3>'+esc(r.b.name)+'</h3><p class="small" style="margin:2px 0 0">'+esc(r.b.style)+'</p><ul>'+r.why.slice(0,3).map(function(w){return '<li>'+esc(w)+'</li>'}).join('')+'</ul></div><a class="btn gold sm" href="bots/'+r.b.id+'.html">See bot</a></div>'});
    h+='</div><p class="small" style="margin-top:18px">Matches are a starting point based on style and risk, not financial advice. Always test on a demo account first.</p><p><button class="btn sm" id="q-again">Start again</button></p>';
    $('#q-body').innerHTML=h;
    $('#q-again').addEventListener('click',function(){ans={};step=0;renderQ()});
  }
  renderQ();
}

/* ---------- tools ---------- */
var lot=$('#lot-form');
if(lot){
  function calcLot(){
    var bal=+$('#l-bal').value,rp=+$('#l-risk').value,sl=+$('#l-sl').value,cs=+$('#l-cs').value;
    var out=$('#l-out');
    if(!(bal>0&&rp>0&&sl>0&&cs>0)){out.innerHTML='<span class="small">Enter your balance, risk and stop loss.</span>';return}
    var risk=bal*rp/100,lots=risk/(sl*cs);
    out.innerHTML='<div class="small">Suggested lot size</div><div class="big">'+(Math.floor(lots*100)/100).toFixed(2)+' lots</div><p class="small" style="margin:8px 0 0">You risk '+money(risk)+' if the stop loss is hit. Round down, never up. Check your broker\'s contract size for XAUUSD.</p>';
  }
  $$('input',lot).forEach(function(i){i.addEventListener('input',calcLot)});calcLot();
}
var rec=$('#rec-form');
if(rec){
  function calcRec(){
    var l=+$('#r-loss').value,o=$('#r-out');
    if(!(l>0&&l<100)){o.innerHTML='<span class="small">Enter a loss between 1 and 99.</span>';return}
    var need=(1/(1-l/100)-1)*100;
    o.innerHTML='<div class="small">Gain needed to get back to even</div><div class="big">'+need.toFixed(1)+'%</div>';
    var rows='';[5,10,20,30,40,50,60,70].forEach(function(x){rows+='<tr><td>'+x+'%</td><td>'+((1/(1-x/100)-1)*100).toFixed(1)+'%</td></tr>'});
    $('#r-table').innerHTML='<tr><th>Loss</th><th>Gain to recover</th></tr>'+rows;
  }
  $('#r-loss').addEventListener('input',calcRec);calcRec();
}
var prop=$('#prop-form');
if(prop){
  var ids=['p-size','p-target','p-daily','p-max','p-bal','p-day'],saved=store.get('tbfx-prop');
  if(saved){try{var sv=JSON.parse(saved);ids.forEach(function(i){if(sv[i]!=null)$('#'+i).value=sv[i]})}catch(e){}}
  function bar(id,pct,cls){var b=$('#'+id);b.className='bar '+cls;b.firstElementChild.style.width=Math.max(0,Math.min(100,pct))+'%'}
  function calcProp(){
    var v={};ids.forEach(function(i){v[i]=+$('#'+i).value});store.set('tbfx-prop',JSON.stringify(v));
    var size=v['p-size'],o=$('#p-out');
    if(!(size>0)){o.innerHTML='<span class="small">Enter your account size.</span>';return}
    var targetAmt=size*v['p-target']/100,dailyAmt=size*v['p-daily']/100,maxAmt=size*v['p-max']/100;
    var profit=v['p-bal']-size,dayLoss=Math.max(0,v['p-day']-v['p-bal']),totalLoss=Math.max(0,size-v['p-bal']);
    var tPct=profit/targetAmt*100,dPct=dayLoss/dailyAmt*100,mPct=totalLoss/maxAmt*100;
    var dLeft=dailyAmt-dayLoss,mLeft=maxAmt-totalLoss,safe=Math.max(0,Math.min(dLeft,mLeft));
    o.innerHTML='<p class="small" style="margin:0">Profit target ('+money(targetAmt)+')</p><div class="bar" id="b1"><div></div></div>'+
     '<p class="small" style="margin:0">Daily loss used ('+money(dayLoss)+' of '+money(dailyAmt)+')</p><div class="bar" id="b2"><div></div></div>'+
     '<p class="small" style="margin:0">Overall loss used ('+money(totalLoss)+' of '+money(maxAmt)+')</p><div class="bar" id="b3"><div></div></div>'+
     '<div class="small">Room before you breach a limit</div><div class="big">'+money(safe)+'</div>'+
     '<p class="small" style="margin:8px 0 0">A cautious rule: never risk more than a third of that room on a single trade. Some firms measure drawdown from equity or a trailing level, so read your firm\'s exact rules.</p>';
    bar('b1',tPct,'');bar('b2',dPct,dPct>80?'bad':dPct>50?'warn':'');bar('b3',mPct,mPct>80?'bad':mPct>50?'warn':'');
  }
  $$('input',prop).forEach(function(i){i.addEventListener('input',calcProp)});calcProp();
}

/* ---------- academy ---------- */
var chk=$('#checklist');
if(chk){
  var st={};try{st=JSON.parse(store.get('tbfx-check')||'{}')}catch(e){}
  function prog(){var all=$$('input',chk),d=all.filter(function(i){return i.checked}).length;$('#chk-prog').textContent=d+' of '+all.length+' done'}
  $$('input',chk).forEach(function(i){
    i.checked=!!st[i.id];i.closest('.check').classList.toggle('done',i.checked);
    i.addEventListener('change',function(){st[i.id]=i.checked;store.set('tbfx-check',JSON.stringify(st));i.closest('.check').classList.toggle('done',i.checked);prog()});
  });prog();
}
var gq=$('#gl-q');
if(gq){gq.addEventListener('input',function(){var q=gq.value.toLowerCase();$$('#gl dt').forEach(function(dt){var dd=dt.nextElementSibling,ok=!q||(dt.textContent+dd.textContent).toLowerCase().indexOf(q)>-1;dt.hidden=!ok;dd.hidden=!ok})})}

/* ---------- contact channels, floating dock, USDT checkout ---------- */
var C=D.config||{};
var ICON={
 whatsapp:'<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>',
 telegram:'<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',
 discord:'<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"/></svg>',
 usdt:'<svg class="usdt-ic" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><circle cx="16" cy="16" r="16" fill="#26A17B"/><path fill="#fff" d="M17.9 17.2v-.002c-.11.008-.678.042-1.942.042-1.01 0-1.721-.03-1.971-.042v.003c-3.888-.171-6.79-.848-6.79-1.658 0-.809 2.902-1.486 6.79-1.66v2.644c.254.018.982.061 1.988.061 1.207 0 1.812-.05 1.925-.06v-2.643c3.88.173 6.775.85 6.775 1.658 0 .81-2.895 1.485-6.775 1.657m0-3.59v-2.366h5.414V7.819H8.595v3.425h5.414v2.365c-4.4.202-7.709 1.074-7.709 2.118 0 1.044 3.309 1.915 7.709 2.118v7.582h3.91v-7.584c4.393-.202 7.694-1.073 7.694-2.116 0-1.043-3.301-1.914-7.694-2.117"/></svg>'
};
function waDigits(){return String(C.whatsapp||'').replace(/\D/g,'')}
function tgUser(){return String(C.telegram||'').replace(/^(https?:\/\/)?t\.me\//i,'').replace('@','')}
function waLink(t){return 'https://wa.me/'+waDigits()+(t?'?text='+encodeURIComponent(t):'')}
function tgLink(t){return 'https://t.me/'+tgUser()+(t?'?text='+encodeURIComponent(t):'')}
function copyText(txt,okMsg){
  function fallback(){var ta=document.createElement('textarea');ta.value=txt;ta.setAttribute('readonly','');ta.style.cssText='position:fixed;left:-999px;top:0';document.body.appendChild(ta);ta.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(ta);toast(ok?okMsg:'Could not copy automatically. Please copy: '+txt)}
  if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(txt).then(function(){toast(okMsg)},fallback)}else fallback();
}
document.addEventListener('click',function(e){
  var b=e.target.closest&&e.target.closest('[data-copy]');if(!b)return;
  e.preventDefault();
  copyText(b.getAttribute('data-copy'),b.getAttribute('data-copied')||'Copied to clipboard.');
});

/* floating contact dock */
(function(){
  var items=[];
  if(waDigits())items.push('<a class="dock-btn wa" href="'+waLink('Hi TechBroFX, I would like some help.')+'" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">'+ICON.whatsapp+'<span class="dock-tip">WhatsApp<small>'+esc(C.whatsapp)+'</small></span></a>');
  if(tgUser())items.push('<a class="dock-btn tg" href="'+tgLink('Hi TechBroFX, I would like some help.')+'" target="_blank" rel="noopener noreferrer" aria-label="Message on Telegram">'+ICON.telegram+'<span class="dock-tip">Telegram<small>t.me/'+esc(tgUser())+'</small></span></a>');
  if(C.discord)items.push('<button type="button" class="dock-btn dc" data-copy="'+esc(C.discord)+'" data-copied="Discord username copied: '+esc(C.discord)+'. Add us on Discord to chat." aria-label="Copy Discord username '+esc(C.discord)+'">'+ICON.discord+'<span class="dock-tip">Discord<small>'+esc(C.discord)+' (tap to copy)</small></span></button>');
  if(!items.length)return;
  var d=document.createElement('aside');d.className='dock';d.setAttribute('aria-label','Contact TechBroFX');
  d.innerHTML='<span class="dock-label">Chat</span>'+items.join('');
  document.body.appendChild(d);
})();

/* footer + enquiry modal quick links, about-page contact cards */
function socialRow(){
  var h='<div class="social">';
  if(waDigits())h+='<a class="wa" href="'+waLink()+'" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp '+esc(C.whatsapp)+'" title="WhatsApp">'+ICON.whatsapp+'</a>';
  if(tgUser())h+='<a class="tg" href="'+tgLink()+'" target="_blank" rel="noopener noreferrer" aria-label="Telegram" title="Telegram">'+ICON.telegram+'</a>';
  if(C.discord)h+='<button type="button" class="dc" data-copy="'+esc(C.discord)+'" data-copied="Discord username copied: '+esc(C.discord)+'" aria-label="Copy Discord username" title="Discord: '+esc(C.discord)+'">'+ICON.discord+'</button>';
  return h+'</div>';
}
var fb=$('.footer .fgrid > div');if(fb)fb.insertAdjacentHTML('beforeend',socialRow());
var mbx=$('#enquiry .modalbox');if(mbx)mbx.insertAdjacentHTML('beforeend','<div class="eq-alt"><span>Prefer to chat? Reach us directly</span>'+socialRow()+'</div>');
var cc=$('#contact-cards');
if(cc){
  var h='';
  if(waDigits())h+='<a class="ccard wa" href="'+waLink('Hi TechBroFX, I would like some help.')+'" target="_blank" rel="noopener noreferrer"><span class="ic">'+ICON.whatsapp+'</span><span><b>WhatsApp</b><small>'+esc(C.whatsapp)+'</small></span><span class="go">Chat</span></a>';
  if(tgUser())h+='<a class="ccard tg" href="'+tgLink('Hi TechBroFX, I would like some help.')+'" target="_blank" rel="noopener noreferrer"><span class="ic">'+ICON.telegram+'</span><span><b>Telegram</b><small>t.me/'+esc(tgUser())+'</small></span><span class="go">Message</span></a>';
  if(C.discord)h+='<button type="button" class="ccard dc" data-copy="'+esc(C.discord)+'" data-copied="Discord username copied: '+esc(C.discord)+'. Add us on Discord to chat."><span class="ic">'+ICON.discord+'</span><span><b>Discord</b><small>'+esc(C.discord)+'</small></span><span class="go">Copy name</span></button>';
  cc.innerHTML=h;
}

/* ---------- header + hero chat icons ---------- */
(function(){
  var nav=$('.topbar .nav'),mbtn=$('.menu-btn');
  if(nav&&(waDigits()||tgUser())){
    var d=document.createElement('div');d.className='hdr-social';
    d.innerHTML=(waDigits()?'<a class="wa" href="'+waLink('Hi TechBroFX, I would like some help.')+'" target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp" title="WhatsApp">'+ICON.whatsapp+'</a>':'')+(tgUser()?'<a class="tg" href="'+tgLink('Hi TechBroFX, I would like some help.')+'" target="_blank" rel="noopener noreferrer" aria-label="Message us on Telegram" title="Telegram">'+ICON.telegram+'</a>':'');
    nav.insertBefore(d,mbtn||null);
  }
  var hb=$('.hero .wrap > div[style*="display:flex"]');
  if(hb&&(waDigits()||tgUser())){hb.insertAdjacentHTML('beforeend',socialRow().replace('class="social"','class="social hero-social"'))}
})();

/* ---------- USDT checkout (prices, networks and wallet addresses are all editable in data.js) ---------- */
var NETS=(C.usdt&&C.usdt.networks&&C.usdt.networks.length)?C.usdt.networks:[{id:'trc20',name:'TRC20',chain:'Tron',note:'Usually the lowest fee',address:(C.usdt||{}).trc20||''},{id:'bep20',name:'BEP20',chain:'BNB Smart Chain',note:'Low fee',address:(C.usdt||{}).bep20||''},{id:'erc20',name:'ERC20',chain:'Ethereum',note:'Highest network fee',address:(C.usdt||{}).erc20||''}];
function getBot(id){return D.bots.filter(function(x){return x.id===id})[0]}
function num(s){var n=parseFloat(String(s||'').replace(/[^0-9.]/g,''));return isFinite(n)?n:0}
function fmt(n){return n?(n%1?n.toFixed(2):String(n)):'0'}
function perText(p){var per=String(p.per||'');return per?(per.charAt(0)==='/'?'per '+per.slice(1).trim():per):''}
function askMsg(B){return 'Hi TechBroFX, I would like to ask about '+B.name+' ('+B.platforms.join(' / ')+').'}
function askRow(B){
  if(!waDigits()&&!tgUser())return '';
  return '<div class="askrow"><span class="small">Questions about '+esc(B.name)+'? Message us before you buy.</span><div class="ask-btns">'+
   (waDigits()?'<a class="btn wa sm" href="'+waLink(askMsg(B))+'" target="_blank" rel="noopener noreferrer">'+ICON.whatsapp+'Ask on WhatsApp</a>':'')+
   (tgUser()?'<a class="btn tg sm" href="'+tgLink(askMsg(B))+'" target="_blank" rel="noopener noreferrer">'+ICON.telegram+'Ask on Telegram</a>':'')+'</div></div>';
}
var inlineApi=null;
function renderCheckout(root,B,uid,opts){
  opts=opts||{};
  var q=function(s){return $(s,root)},hasPlans=B.plans&&B.plans.length;
  var pop=hasPlans?B.plans.map(function(p){return !!p.popular}).indexOf(true):-1;
  var st={plan:hasPlans?(pop>-1?pop:0):-1,net:NETS[0].id,ref:'TBFX-'+Date.now().toString(36).toUpperCase().slice(-6)};
  if(typeof opts.plan==='number'&&hasPlans)st.plan=opts.plan;
  var acctLabel=(B.platforms.indexOf('MetaTrader 5')>-1&&B.platforms.indexOf('TradeLocker')>-1)?'MT5 account number or TradeLocker email':(B.platforms.indexOf('TradeLocker')>-1?'Your TradeLocker email':'Your MT5 account number');
  var h=(opts.modal?'<div class="sec-head" style="margin-bottom:22px"><h2 id="'+uid+'-h">Buy '+esc(B.name)+'</h2><p>Choose a price, pick how you want to pay and send your order. We activate it once the transfer is confirmed.</p></div>':'<div class="wrap"><div class="sec-head"><h2 id="co-h">Checkout</h2><p>Choose a price, pick how you want to pay and send your order. We activate it once the transfer is confirmed.</p></div>')+'<div class="checkout"><div class="co-main">';
  h+='<div class="co-block"><h3 class="co-step"><b>1</b>Choose your price</h3><p class="co-sub">Prices are in US dollars and paid in USDT, 1 USDT = 1 USD.</p><div class="co-plans" role="radiogroup" aria-label="Price option">';
  B.plans.forEach(function(p,i){h+='<button type="button" class="co-opt co-plan" role="radio" aria-checked="'+(i===st.plan)+'" data-i="'+i+'">'+(p.popular?'<span class="badge">Popular</span>':'')+'<span class="t">'+esc(p.name)+'</span><span class="pr">'+esc(p.price)+'<small>'+esc(p.per||'')+'</small></span><span class="n">'+esc(p.note||'')+'</span></button>'});
  h+='</div></div>';
  h+='<div class="co-block"><h3 class="co-step"><b>2</b>Payment method</h3><p class="co-sub">Pay with USDT (Tether). Choose the network you will send on. It must match the wallet address exactly.</p>';
  h+='<div class="co-method"><span class="co-pill" aria-checked="true">'+ICON.usdt+'USDT (Tether)</span><span class="small">Want to pay another way? Ask us on WhatsApp or Telegram.</span></div>';
  h+='<div class="co-nets many" role="radiogroup" aria-label="USDT network">';
  NETS.forEach(function(n){h+='<button type="button" class="co-opt co-net" role="radio" aria-checked="'+(n.id===st.net)+'" data-n="'+esc(n.id)+'">'+ICON.usdt+'<span class="t">'+esc(n.name)+'</span><span class="n">'+esc(n.chain)+'<br>'+esc(n.note||'')+'</span></button>'});
  h+='</div><div class="js-addr"></div><div class="note warn co-warn">Send only <b>USDT</b> on the network you selected. A different coin or network can mean your funds are lost for good. Only use wallet addresses shown on this site or sent by our official WhatsApp, Telegram or Discord, and check the first and last characters before you send.</div></div>';
  h+='<div class="co-block"><h3 class="co-step"><b>3</b>Proceed to checkout</h3><p class="co-sub">Fill in what you can. Your order opens in WhatsApp or Telegram ready to send, and we reply with the next steps.</p><div class="co-fields">';
  h+='<div class="field"><label for="'+uid+'-name">Your name</label><input id="'+uid+'-name" autocomplete="name"></div><div class="field"><label for="'+uid+'-contact">Telegram, WhatsApp or email</label><input id="'+uid+'-contact"></div>';
  h+='<div class="field full"><label for="'+uid+'-acct">'+acctLabel+'</label><input id="'+uid+'-acct"></div><div class="field full"><label for="'+uid+'-tx">Transaction hash (TXID), add it after you have paid</label><input id="'+uid+'-tx" placeholder="Optional until you have sent the payment"></div></div>';
  h+='<div class="co-actions">';
  if(waDigits())h+='<button type="button" class="btn wa js-wa">'+ICON.whatsapp+'Send order on WhatsApp</button>';
  if(tgUser())h+='<button type="button" class="btn tg js-tg">'+ICON.telegram+'Send order on Telegram</button>';
  if(C.discord)h+='<button type="button" class="btn dc full js-dc">'+ICON.discord+'Copy order for Discord ('+esc(C.discord)+')</button>';
  h+='</div>'+askRow(B)+'</div></div>';
  h+='<aside class="co-sum" aria-label="Order summary"><img class="cov" src="'+(opts.base||'')+esc(B.image||('assets/img/bots/'+B.id+'.svg'))+'" alt="'+esc(B.name)+' cover art" width="640" height="360"><div class="in"><h3>'+esc(B.name)+'</h3><div class="js-rows"></div><div class="co-total"><span class="small">You pay</span><b class="js-total">0 USDT</b></div><div class="co-ref js-ref"></div><div class="co-accept">'+ICON.usdt+'USDT accepted on '+NETS.length+' networks</div></div></aside></div>'+(opts.modal?'':'</div>');
  root.innerHTML=h;
  function plan(){return st.plan>-1?B.plans[st.plan]:null}
  function net(){return NETS.filter(function(n){return n.id===st.net})[0]}
  function amount(){var p=plan();return p?num(p.price):0}
  function drawSummary(){
    var p=plan(),n=net(),a=amount();
    q('.js-rows').innerHTML='<div class="co-row"><span>Platform</span><span>'+esc(B.platforms.join(' / '))+'</span></div><div class="co-row"><span>Price option</span><span>'+(p?esc(p.name)+(perText(p)?' &middot; '+esc(perText(p)):''):'--')+'</span></div><div class="co-row"><span>Payment</span><span>USDT '+esc(n.name)+'</span></div>';
    q('.js-total').textContent=(a?fmt(a):'--')+' USDT';
    q('.js-ref').textContent='Order ref: '+st.ref;
  }
  function drawAddr(){
    var n=net(),ad=String(n.address||(C.usdt||{})[n.id]||'').trim(),box=q('.js-addr');
    if(ad){box.innerHTML='<div class="co-addr"><span class="lbl">Send USDT on <b>'+esc(n.name)+' ('+esc(n.chain)+')</b> to:</span><code>'+esc(ad)+'</code><button type="button" class="btn sm" data-copy="'+esc(ad)+'" data-copied="Wallet address copied. Double check it before you send.">Copy address</button></div>'}
    else{box.innerHTML='<div class="co-addr"><span class="lbl">Wallet address for <b>USDT '+esc(n.name)+'</b></span><p class="small" style="margin:8px 0 0">We send you the wallet address together with your order ref <b>'+st.ref+'</b>. Complete step 3 and we will reply with it.</p></div>'}
  }
  function v(id){var e=$('#'+uid+'-'+id,root);return e?e.value.trim():''}
  function order(){
    var p=plan(),n=net(),a=amount();
    var L=['TechBroFX order request','Ref: '+st.ref,'Bot: '+B.name,'Platform: '+B.platforms.join(' / '),'Price option: '+(p?p.name+' ('+p.price+(p.per?' '+p.per:'')+')':'--'),'Amount: '+(a?fmt(a)+' USDT':'to be confirmed'),'Payment: USDT '+n.name+' ('+n.chain+')'];
    if(v('name'))L.push('Name: '+v('name'));
    if(v('contact'))L.push('Contact: '+v('contact'));
    if(v('acct'))L.push(acctLabel.replace(/^Your /,'')+': '+v('acct'));
    if(v('tx'))L.push('TXID: '+v('tx'));
    L.push('',v('tx')?'I have sent the payment. Please confirm and activate.':'Please send me the wallet address to pay.');
    return L.join('\n');
  }
  function selectPlan(i){st.plan=i;$$('.co-plan',root).forEach(function(x){x.setAttribute('aria-checked',+x.dataset.i===i)});drawSummary()}
  $$('.co-plan',root).forEach(function(b){b.addEventListener('click',function(){selectPlan(+b.dataset.i)})});
  $$('.co-net',root).forEach(function(b){b.addEventListener('click',function(){st.net=b.dataset.n;$$('.co-net',root).forEach(function(x){x.setAttribute('aria-checked',x===b)});drawAddr();drawSummary()})});
  var bw=q('.js-wa');if(bw)bw.addEventListener('click',function(){window.open(waLink(order()),'_blank','noopener');toast('Opening WhatsApp with your order ready to send.')});
  var bt=q('.js-tg');if(bt)bt.addEventListener('click',function(){window.open(tgLink(order()),'_blank','noopener');toast('Opening Telegram with your order ready to send.')});
  var bd=q('.js-dc');if(bd)bd.addEventListener('click',function(){copyText(order(),'Order copied. Send it to '+C.discord+' on Discord.')});
  drawAddr();drawSummary();
  return {selectPlan:selectPlan};
}

/* inline checkout on each bot page */
var co=$('#checkout');
if(co){
  var cb=getBot(co.getAttribute('data-bot'));
  if(cb){inlineApi=renderCheckout(co,cb,'co',{base:/\/bots\//.test(location.pathname)?'../':''})}
}

/* sidebar buy box on each bot page: prices, buy now, ask on WhatsApp / Telegram */
var bb=$('[data-buybox]');
if(bb){
  var bB=getBot(bb.getAttribute('data-buybox'));
  if(bB){
    var bh='<div class="bb-label">Choose a price</div><div class="bb-plans">';
    bB.plans.forEach(function(p,i){bh+='<button type="button" class="bb-plan'+(p.popular?' pop':'')+'" data-i="'+i+'"><span>'+esc(p.name)+(p.popular?' <em>Popular</em>':'')+'<small>'+esc(p.note||'')+'</small></span><b>'+esc(p.price)+'<small>'+esc(p.per||'')+'</small></b></button>'});
    bh+='</div><a class="btn gold block bb-buy" href="#checkout">'+ICON.usdt+'Buy now with USDT</a><p class="small" style="margin:8px 0 0;text-align:center">Pay on '+NETS.length+' networks including TRC20, ERC20 and Solana.</p>';
    if(bB.link)bh+='<p style="margin:12px 0 0"><a class="btn block" href="'+esc(bB.link)+'" target="_blank" rel="noopener">'+esc(bB.link_label||'View listing')+'</a></p>';
    bh+=askRow(bB);
    bb.innerHTML=bh;
    function goCo(){var s=$('#checkout');if(s)s.scrollIntoView({behavior:'smooth',block:'start'})}
    $$('.bb-plan',bb).forEach(function(b){b.addEventListener('click',function(){if(inlineApi)inlineApi.selectPlan(+b.dataset.i);goCo()})});
  }
}

/* "Buy now" on bot cards: opens checkout in a popup so the buyer can pick price and USDT network straight away */
var buyModal=null;
function openBuy(id,planIdx){
  var B=getBot(id);if(!B)return;
  if(!buyModal){
    buyModal=document.createElement('div');buyModal.className='modal';buyModal.setAttribute('role','dialog');buyModal.setAttribute('aria-modal','true');
    buyModal.innerHTML='<div class="modalbox modal-buy"><button type="button" class="x" data-close aria-label="Close">\u00d7</button><div class="buy-root"></div></div>';
    document.body.appendChild(buyModal);
    buyModal.addEventListener('click',function(e){if(e.target===buyModal||e.target.closest('[data-close]'))buyModal.classList.remove('open')});
  }
  renderCheckout($('.buy-root',buyModal),B,'bm',{modal:true,plan:planIdx,base:/\/bots\//.test(location.pathname)?'../':''});
  buyModal.classList.add('open');$('.modalbox',buyModal).scrollTop=0;
}
$$('[data-buy]').forEach(function(b){b.addEventListener('click',function(){openBuy(b.getAttribute('data-buy'))})});
})();
