window.TBFX={
 "config": {
  "brand": "TechBroFX",
  "telegram": "TechbroFX",
  "email": "",
  "whatsapp": "+254739298328",
  "mql5_profile": "",
  "tradelocker_vita": "https://tradelocker.com/hub/bots/vita-1",
  "discord": "triple888ke",
  "usdt": {
   "note": "Paste your wallet address into the 'address' field of each network. Leave one empty and the checkout tells the buyer to request that address from you on WhatsApp or Telegram. Delete any network you do not want to offer.",
   "networks": [
    {
     "id": "trc20",
     "name": "TRC20",
     "chain": "Tron",
     "note": "Usually the lowest fee",
     "address": ""
    },
    {
     "id": "bep20",
     "name": "BEP20",
     "chain": "BNB Smart Chain",
     "note": "Low fee",
     "address": ""
    },
    {
     "id": "erc20",
     "name": "ERC20",
     "chain": "Ethereum",
     "note": "Highest network fee",
     "address": ""
    },
    {
     "id": "solana",
     "name": "Solana",
     "chain": "Solana (SPL)",
     "note": "Fast, very low fee",
     "address": ""
    },
    {
     "id": "polygon",
     "name": "Polygon",
     "chain": "Polygon PoS",
     "note": "Low fee",
     "address": ""
    },
    {
     "id": "arbitrum",
     "name": "Arbitrum",
     "chain": "Arbitrum One",
     "note": "Low fee",
     "address": ""
    },
    {
     "id": "optimism",
     "name": "Optimism",
     "chain": "OP Mainnet",
     "note": "Low fee",
     "address": ""
    },
    {
     "id": "base",
     "name": "Base",
     "chain": "Base",
     "note": "Low fee",
     "address": ""
    },
    {
     "id": "avalanche",
     "name": "Avalanche",
     "chain": "Avalanche C-Chain",
     "note": "Low fee",
     "address": ""
    },
    {
     "id": "ton",
     "name": "TON",
     "chain": "The Open Network",
     "note": "Low fee",
     "address": ""
    }
   ]
  }
 },
 "bots": [
  {
   "id": "vita-tradelocker",
   "name": "VITA",
   "platforms": [
    "TradeLocker"
   ],
   "style": "Rules-based gold bot",
   "risk": 2,
   "level": "beginner",
   "grid": false,
   "news": false,
   "summary": "Our flagship gold bot for TradeLocker. Subscribe, get approved, and let it follow a fixed rule set on XAUUSD.",
   "features": [
    "Automated rule-based execution",
    "Backtest in TradeLocker Studio first",
    "Invite-only, activated after payment"
   ],
   "how": "VITA automates one repeatable approach on gold so you do not have to watch every candle. It runs inside TradeLocker, and access is granted by us after your payment is confirmed. You can test it in TradeLocker Studio before switching it on for a live account.",
   "best_for": "New traders on TradeLocker who want one simple bot and a short commitment.",
   "caution": "Access is approved manually. Run it on a demo account first, and check your broker or prop firm allows automation.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "https://tradelocker.com/hub/bots/vita-1",
   "link_label": "View on TradeLocker",
   "image": "assets/img/bots/vita-tradelocker.svg"
  },
  {
   "id": "techbros-ai-grid",
   "name": "TECHBROS AI GRID",
   "platforms": [
    "MetaTrader 5",
    "TradeLocker"
   ],
   "style": "Trend grid",
   "risk": 3,
   "level": "intermediate",
   "grid": true,
   "news": false,
   "summary": "EMA trend system with a grid, higher-timeframe trend filter and automatic reset after profit targets. Also ported to TradeLocker.",
   "features": [
    "EMA trend signals",
    "Higher-timeframe trend filter",
    "Auto-reset after session or daily profit target",
    "Sound alerts"
   ],
   "how": "Part of the TECHBROS AI ELITE line. It reads the trend with EMAs, filters trades against a higher timeframe, and can stop for the day once a profit target is hit. A TradeLocker version exists alongside the MT5 one.",
   "best_for": "Traders who understand that grids add to losing positions and want a daily profit-target reset.",
   "caution": "Grid systems can hold several positions at once. Use small lots and a hard stop-out level.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$129",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$260",
     "per": "/ 3 months",
     "note": "Save $127 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$1299",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/techbros-ai-grid.svg"
  },
  {
   "id": "quantum-confluence-gold-ai",
   "name": "QUANTUM CONFLUENCE GOLD AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Multi-engine confluence",
   "risk": 2,
   "level": "intermediate",
   "grid": false,
   "news": false,
   "summary": "A trade only opens when several independent engines agree: overbought/oversold, support/resistance, moving averages, volatility and price action.",
   "features": [
    "Six engines, each with its own timeframe",
    "10 price action patterns and 10 breakout types",
    "Live on-chart dashboard with an AI confidence gauge",
    "Optional grid, off by default"
   ],
   "how": "Think of it as a committee vote. The OB/OS engine, S/R engine, MA engine (including Hull MA), volatility filter, price action and breakout engines each get a say, and every enabled engine must agree before a trade opens. Signals are read on closed bars only.",
   "best_for": "Traders who want fewer, more selective entries and a dashboard that shows why.",
   "caution": "Many settings means many ways to over-tune it. Start from defaults on demo.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/quantum-confluence-gold-ai.svg"
  },
  {
   "id": "quantum-queen-ai",
   "name": "QUANTUM QUEEN AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Adaptive confluence",
   "risk": 2,
   "level": "intermediate",
   "grid": false,
   "news": true,
   "summary": "A 15-strategy confluence engine with market regime detection and news protection built on the MQL5 economic calendar.",
   "features": [
    "15-strategy confluence engine",
    "Adaptive engine detects market regime",
    "News protection via MQL5 calendar",
    "Pyramid trading option"
   ],
   "how": "Quantum Queen scores many strategies together and adapts to the current market regime. It pauses around high-impact news using the built-in MQL5 economic calendar.",
   "best_for": "Traders who want a bot that adapts and steps aside during news.",
   "caution": "Pyramiding adds size to winners and can add risk if it reverses. Test the setting before using it live.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/quantum-queen-ai.svg"
  },
  {
   "id": "quantum-king-ai",
   "name": "QUANTUM KING AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Grid scalper with recovery",
   "risk": 3,
   "level": "advanced",
   "grid": true,
   "news": false,
   "summary": "A grid scalper with a recovery engine. Built for traders who want an active, high-frequency style and accept the extra risk.",
   "features": [
    "Grid scalping",
    "Recovery engine",
    "On-chart HUD"
   ],
   "how": "Quantum King opens a first trade and manages follow-up positions with a grid and a recovery engine, aiming to close the basket in profit.",
   "best_for": "Experienced traders who can size a grid safely.",
   "caution": "Recovery and grid styles can produce large drawdowns in strong trends. Not a first bot.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$129",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$260",
     "per": "/ 3 months",
     "note": "Save $127 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$1299",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/quantum-king-ai.svg"
  },
  {
   "id": "king-scalper-pro",
   "name": "KING SCALPER PRO",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Price action scalper",
   "risk": 2,
   "level": "intermediate",
   "grid": false,
   "news": false,
   "summary": "A gold scalper that reads candle patterns. Pick from ten price action types and run up to five slots at once.",
   "features": [
    "Price action engine, 10 pattern types",
    "Up to 5 independent pattern slots",
    "Quantum HUD dashboard"
   ],
   "how": "King Scalper Pro looks for specific candle patterns on gold and lets you run several pattern slots side by side, each independent. The Quantum HUD shows what it sees.",
   "best_for": "Traders who like price action and want to see the logic on the chart.",
   "caution": "Scalping is sensitive to spread. Use a low-spread broker and check the spread cap.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/king-scalper-pro.svg"
  },
  {
   "id": "vita-ai-sniper",
   "name": "VITA AI SNIPER",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Sniper entries",
   "risk": 2,
   "level": "beginner",
   "grid": false,
   "news": false,
   "summary": "The sniper version of VITA AI for MT5, published on the MQL5 Market with a gold dashboard.",
   "features": [
    "Built for XAUUSD",
    "Gold-themed dashboard",
    "Published on MQL5 Market"
   ],
   "how": "VITA AI Sniper is one of the VITA AI family of gold bots. It is aimed at selective entries and ships with a clean dashboard.",
   "best_for": "New MT5 users who want a ready-made gold bot with a clear dashboard.",
   "caution": "Check the live Strategy Tester report on the listing before you decide.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$79",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$160",
     "per": "/ 3 months",
     "note": "Save $77 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$699",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/vita-ai-sniper.svg"
  },
  {
   "id": "vita-quantum-ai",
   "name": "VITA QUANTUM AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Adaptive auto-switching",
   "risk": 2,
   "level": "intermediate",
   "grid": false,
   "news": false,
   "summary": "Switches between five AI personalities depending on which of seven market regimes it detects.",
   "features": [
    "5 AI personalities",
    "7 market regime classifications",
    "Adaptive auto-switching mode"
   ],
   "how": "Instead of one fixed approach, Vita Quantum classifies the market into seven regimes and swaps personality to suit, for example trending versus ranging conditions.",
   "best_for": "Traders who want a bot that changes behaviour with the market.",
   "caution": "Adaptive does not mean safe. Watch it on demo through different conditions.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/vita-quantum-ai.svg"
  },
  {
   "id": "scorpion-sniper-ai",
   "name": "SCORPION SNIPER AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Modular sniper",
   "risk": 2,
   "level": "intermediate",
   "grid": false,
   "news": false,
   "summary": "A modular gold EA. Switch strategy modules on and off, including ten moving average types, and load themed set files.",
   "features": [
    "Modular design",
    "Moving average module with 10 subtypes",
    "Themed .set files ready to load"
   ],
   "how": "Scorpion Sniper is built from modules you can enable one at a time. Ready-made set files make it quick to load a tested configuration.",
   "best_for": "Traders who want to experiment one module at a time.",
   "caution": "More modules means more combinations. Change one setting at a time.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/scorpion-sniper-ai.svg"
  },
  {
   "id": "the-council-grid",
   "name": "THE COUNCIL GRID",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Council grid",
   "risk": 3,
   "level": "advanced",
   "grid": true,
   "news": false,
   "summary": "A council-style grid EA with a luxury-car inspired dashboard.",
   "features": [
    "Council-style signal logic",
    "Grid management",
    "Luxury-car style dashboard"
   ],
   "how": "The Council Grid combines several signal voters with a grid to manage positions, and displays everything on a car-dash style panel.",
   "best_for": "Experienced traders comfortable with grid risk.",
   "caution": "Grid exposure grows when price moves against you. Use strict lot sizing.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$129",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$260",
     "per": "/ 3 months",
     "note": "Save $127 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$1299",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/the-council-grid.svg"
  },
  {
   "id": "ixo-aurum-smartrecovery",
   "name": "IXO AURUM SMART RECOVERY",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Council grid with smart news protection",
   "risk": 3,
   "level": "advanced",
   "grid": true,
   "news": true,
   "summary": "A council and grid EA with simple SL/TP in ATR or pips, plus smart news protection.",
   "features": [
    "SL/TP in ATR or fixed pips",
    "Smart news protection",
    "Recovery management"
   ],
   "how": "IXO AURUM uses council-style signals with grid recovery. Stops and targets can be set as an ATR multiple or a fixed pip value, and news protection helps it avoid high-impact releases.",
   "best_for": "Experienced traders who want a recovery style with a news safeguard.",
   "caution": "Recovery logic still carries drawdown risk. News filters reduce, not remove, event risk.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$129",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$260",
     "per": "/ 3 months",
     "note": "Save $127 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$1299",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/ixo-aurum-smartrecovery.svg"
  },
  {
   "id": "magic-gold-sniper",
   "name": "MAGIC GOLD SNIPER",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Sniper with news filter",
   "risk": 2,
   "level": "beginner",
   "grid": false,
   "news": true,
   "summary": "A gold sniper with a news and NFP filter so it steps aside around major releases.",
   "features": [
    "News filter",
    "NFP filter",
    "Built for XAUUSD"
   ],
   "how": "Magic Gold Sniper focuses on selective gold entries and avoids trading around news such as Non-Farm Payrolls, when gold can move sharply.",
   "best_for": "New traders who want a bot that avoids the most volatile news moments.",
   "caution": "News filters cannot predict every spike. Keep lots small.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$79",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$160",
     "per": "/ 3 months",
     "note": "Save $77 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$699",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/magic-gold-sniper.svg"
  },
  {
   "id": "smart-grid-scalper",
   "name": "SMART GRID SCALPER",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Hedge grid scalper",
   "risk": 3,
   "level": "advanced",
   "grid": true,
   "news": false,
   "summary": "A true-hedge grid scalper using EMA slope, RSI and ATR-based spacing, with basket and session profit targets.",
   "features": [
    "EMA slope across M1, M5, M15",
    "ATR-based grid spacing, SL and TP",
    "Basket and session profit targets"
   ],
   "how": "It reads EMA slope and RSI, spaces its grid with ATR, and can close everything once a basket or session profit target is reached.",
   "best_for": "Experienced traders who want profit-target controls on a grid.",
   "caution": "Hedged grids tie up margin. Know your margin level before running it.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$129",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$260",
     "per": "/ 3 months",
     "note": "Save $127 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$1299",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/smart-grid-scalper.svg"
  },
  {
   "id": "techbros-academy-ai",
   "name": "TECHBROS ACADEMY AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "AI-confirmed entries",
   "risk": 2,
   "level": "intermediate",
   "grid": false,
   "news": false,
   "summary": "Uses an LLM as a second opinion: the EA finds a setup and an AI model confirms or rejects it.",
   "features": [
    "LLM AI confirmation",
    "Filter stack",
    "Built on the Tech Bros Academy engine"
   ],
   "how": "When the EA spots a setup, it can ask a language model to confirm the trade before it opens. The AI step is a filter, not a crystal ball.",
   "best_for": "Curious traders who want to see how AI fits into trade selection.",
   "caution": "AI confirmation adds a filter, not certainty. Needs an API key and web request permission.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$99",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$200",
     "per": "/ 3 months",
     "note": "Save $97 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$999",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/techbros-academy-ai.svg"
  },
  {
   "id": "techbrofx-ai",
   "name": "TECHBROFX AI",
   "platforms": [
    "MetaTrader 5"
   ],
   "style": "Support/resistance and trend",
   "risk": 2,
   "level": "beginner",
   "grid": false,
   "news": false,
   "summary": "Trades gold from support and resistance zones and only in the direction of the trend filter.",
   "features": [
    "Support/resistance engine",
    "Trend filter",
    "Built for XAUUSD"
   ],
   "how": "TechBroFX AI marks key support and resistance levels and only takes trades that agree with the trend filter. Simple logic that is easy to follow on a chart.",
   "best_for": "New traders who want logic they can understand at a glance.",
   "caution": "Trend filters lag. Expect missed moves as well as avoided losses.",
   "plans": [
    {
     "name": "Monthly",
     "price": "$79",
     "per": "/ month",
     "note": "Flexible access"
    },
    {
     "name": "Quarterly",
     "price": "$160",
     "per": "/ 3 months",
     "note": "Save $77 vs monthly",
     "popular": true
    },
    {
     "name": "Lifetime",
     "price": "$699",
     "per": "one-time",
     "note": "Terms apply"
    }
   ],
   "link": "",
   "link_label": "",
   "image": "assets/img/bots/techbrofx-ai.svg"
  }
 ]
};
